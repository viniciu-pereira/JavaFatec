/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.aula1509;

/**
 *
 * @author 1091392313042
 */
public interface ExameDependenciaInterface {
    
    public Double validarAprovacao(Double media, Double notaExame);
}
